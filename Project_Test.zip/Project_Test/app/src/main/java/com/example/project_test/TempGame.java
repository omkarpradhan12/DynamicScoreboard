package com.example.project_test;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.Random;

public class TempGame extends AppCompatActivity {
    String x = "";
    String u,g;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_game);

        setTitle("Temporary Game");

    }

    public void clr(View v)
    {
        LinearLayout ll = (LinearLayout)findViewById(R.id.fragment1);
        ll.removeAllViewsInLayout();

    }





    public void tempplayer(View v)
    {
        AlertDialog.Builder alert = new AlertDialog.Builder(TempGame.this);
        final EditText editText = new EditText(TempGame.this);

        alert.setTitle("Enter Player Name !");
        alert.setView(editText);

        alert.setPositiveButton("Add Player", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String et = editText.getText().toString();
                System.out.println(et);

                LinearLayout ll = findViewById(R.id.fragment1);
                int x=0;
                x = ll.getChildCount() + 1;
                Bundle bundle = new Bundle();
                bundle.putString("edttext", et);
                bundle.putString("Score", "0");
                FragmentManager fm = getFragmentManager();
                FragmentTransaction fragmentTransaction = fm.beginTransaction();
                Frag_1 fm2 = new Frag_1();
                fm2.setArguments(bundle);
                fragmentTransaction.add(R.id.fragment1, fm2, "HELLO");
                fragmentTransaction.commit();
            }
        });

        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(TempGame.this,"Player Not Added",Toast.LENGTH_SHORT).show();
            }
        });

        alert.show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.logout:
                Intent intent = new Intent(TempGame.this, LoginActivity.class);
                startActivity(intent);
                this.finish();
                return true;
            case R.id.closeapp:


                AlertDialog.Builder alert = new AlertDialog.Builder(TempGame.this);
                alert.setTitle("Sure ? ");
                alert.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                });

                alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                alert.show();
                return true;
            case R.id.back:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}